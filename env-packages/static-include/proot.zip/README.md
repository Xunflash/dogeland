proot
=====

This is a copy of [the PRoot project](https://github.com/proot-me/PRoot/) with patches applied to work better under [dogeland](https://github.com/dogelands/dogeland).
