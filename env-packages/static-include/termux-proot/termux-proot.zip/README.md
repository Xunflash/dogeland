proot
=====
This is a copy of [the PRoot project](https://github.com/proot-me/PRoot/)  applied to work better under [dogeland].
